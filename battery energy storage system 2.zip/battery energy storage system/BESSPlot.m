% Plot Grid Usage without and with BESS and Battery SoC overlay
% Compute Peak Demand and total Energy Usage
plot(LoadProfile(:,2),'r','linewidth',2);
hold on
plot(WithBESS,'b','linewidth',2);
ylabel('Power (kW)');
yyaxis right;
plot(BatterySoC,'linewidth',2,'color','y');
ylabel('Battery SOC (%)');
title('Load Profile without and with BESS and Battery SoC');
xlim([1 length(WithBESS)]);

if length(WithBESS) <= 24
    set(gca,'XTick',1:length(WithBESS));
    set(gca,'XTickLabel',0:length(WithBESS)-1);
    xlabel('Hour');
else
    set(gca,'XTick',1:24:length(WithBESS));
    set(gca,'XTickLabel',1:length(WithBESS)/24);
    xlabel('Day');
end


legend(['Load Profile ',sprintf('%0.0f',sum(LoadProfile(:,2))),' kWh',...
       sprintf('\nPeak Demand %0.0f',max(LoadProfile(:,2))), ' kW'],...
       ['With BESS ',sprintf('%0.0f',sum(WithBESS)),' kWh',...
       sprintf('\nPeak Demand %0.0f',max(WithBESS)), ' kW'],...
       ['Battery SoC ',sprintf('%0.1f',min(BatterySoC(2:length(BatterySoC)))),' %']);
